#+:packaged-actr (in-package :act-r)
#+(and :clean-actr (not :packaged-actr) :ALLEGRO-IDE) (in-package :cg-user)
#-(or (not :clean-actr) :packaged-actr :ALLEGRO-IDE) (in-package :cl-user)


(defvar *max-slot-count* 0)
(defvar *max-slot-count-lock* (bt:make-lock))
(defvar *zero-slot-vector* (make-array (list 1) :element-type 'bit :initial-element 0))
(defvar *one-slot-vector* (make-array (list 1) :element-type 'bit :initial-element 1))

(defun slot-count-handler (set-or-get value)
  (bt:with-lock-held (*max-slot-count-lock*)
    (if set-or-get
        (progn
          (setf *zero-slot-vector* (make-array (list value) :element-type 'bit :initial-element 0))
          (setf *one-slot-vector* (make-array (list value) :element-type 'bit :initial-element 1))
          (setf *max-slot-count* value))
      *max-slot-count*)))

(create-system-parameter :slot-count :valid-test (lambda (x) (and (integerp x) (plusp x) (null (mp-models)))) 
                         :default-value 128
                         :warning "a positive integer with no current models"
                         :documentation "maximum number of different slots usable in a model" 
                         :handler 'slot-count-handler)

(provide "SLOT-COUNT")